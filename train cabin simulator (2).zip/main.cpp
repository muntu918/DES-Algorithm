/*
    Train Cabin Simulator - OpenGL GLUT Project
    ------------------------------------------------------------
    A complete 3D train cabin scene built with classic OpenGL/GLUT.

    Project requirements covered:
    1. Group max 3 members: keep your group information in the report/front page.
    2. 3D scene: full train cabin interior.
    3. Basic transformations: rotation, translation and scaling are used everywhere.
    4. Complex objects: seats, cabin shell, luggage rack, suitcase, fan, windows, picture frame, lamps.
    5. Continuous rotating object: ceiling fan rotates continuously.
    6. Window/external view: animated outside scenery is visible through side and front windows.
    7. Object coordinate and viewing coordinate transformation: keyboard controls transform camera and suitcase.
    8. Textures: procedural textures are generated in code for floor, walls, wood, fabric and metal.

    How to run in Code::Blocks:
    - Create a new GLUT/OpenGL project or open the included .cbp file.
    - Link libraries: freeglut, opengl32, glu32. Some setups use glut32 instead of freeglut.
    - Copy this main.cpp into the project and build/run.
*/

#ifdef _WIN32
#include <windows.h>
#endif

#include <GL/glut.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>

const float PI = 3.14159265358979323846f;

// ----------------------------- Window / camera state -----------------------------
int winW = 1280;
int winH = 720;

float camX = 0.0f;
float camY = 1.55f;
float camZ = 6.6f;
float camYaw = 0.0f;     // yaw = 0 means looking toward negative Z
float camPitch = -2.0f;

// ----------------------------- Animated state -----------------------------
float fanAngle = 0.0f;
float sceneryOffset = 0.0f;

// ----------------------------- Transformable object state -----------------------------
float objX = 0.0f;
float objY = 0.32f;
float objZ = 1.65f;
float objRotY = 0.0f;
float objScale = 1.0f;

// ----------------------------- Texture IDs -----------------------------
GLuint texWood = 0;
GLuint texFabric = 0;
GLuint texFloor = 0;
GLuint texWall = 0;
GLuint texMetal = 0;
GLuint texLeather = 0;

GLUquadric *quadricObj = NULL;

// ----------------------------- Utility functions -----------------------------
float degToRad(float degree)
{
    return degree * PI / 180.0f;
}

void setPlainColor(float r, float g, float b)
{
    glDisable(GL_TEXTURE_2D);
    glColor3f(r, g, b);
}

void useTexture(GLuint tex)
{
    if (tex != 0)
    {
        glEnable(GL_TEXTURE_2D);
        glBindTexture(GL_TEXTURE_2D, tex);
        glColor3f(1.0f, 1.0f, 1.0f);
    }
    else
    {
        glDisable(GL_TEXTURE_2D);
    }
}

GLuint createProceduralTexture(int type)
{
    const int S = 96;
    GLubyte data[S][S][3];

    for (int y = 0; y < S; y++)
    {
        for (int x = 0; x < S; x++)
        {
            int r = 255, g = 255, b = 255;

            if (type == 0) // wood texture
            {
                float wave = sinf((float)x * 0.20f + sinf((float)y * 0.18f) * 1.2f);
                int grain = (x * 13 + y * 7 + (x * y) % 19) % 18;
                r = 122 + (int)(wave * 23) + grain;
                g = 78 + (int)(wave * 15) + grain / 2;
                b = 35 + (int)(wave * 8);
            }
            else if (type == 1) // blue woven fabric
            {
                int weave = ((x / 4) % 2) * 18 + ((y / 4) % 2) * 13;
                int line = (x % 12 == 0 || y % 12 == 0) ? 30 : 0;
                r = 28 + weave / 3;
                g = 52 + weave + line / 3;
                b = 105 + weave + line;
            }
            else if (type == 2) // floor carpet / rubber texture
            {
                int checker = ((x / 12) + (y / 12)) % 2;
                int noise = (x * 17 + y * 31 + x * y) % 22;
                r = 45 + checker * 18 + noise;
                g = 47 + checker * 18 + noise;
                b = 52 + checker * 20 + noise;
            }
            else if (type == 3) // wall panel texture
            {
                int panelLine = (x % 24 == 0 || y % 32 == 0) ? 22 : 0;
                int soft = (x * 3 + y * 5) % 10;
                r = 195 - panelLine + soft;
                g = 184 - panelLine + soft;
                b = 165 - panelLine + soft / 2;
            }
            else if (type == 4) // brushed metal
            {
                int streak = (x * 9 + y * 3) % 28;
                int line = (y % 8 == 0) ? 20 : 0;
                r = 128 + streak + line;
                g = 132 + streak + line;
                b = 137 + streak + line;
            }
            else if (type == 5) // red leather / suitcase body
            {
                int p = ((x / 8) % 2) * 8 + ((y / 8) % 2) * 8;
                int grain = (x * 11 + y * 19) % 12;
                r = 105 + p + grain;
                g = 22 + grain / 2;
                b = 24 + grain / 2;
            }

            if (r < 0) r = 0; if (r > 255) r = 255;
            if (g < 0) g = 0; if (g > 255) g = 255;
            if (b < 0) b = 0; if (b > 255) b = 255;

            data[y][x][0] = (GLubyte)r;
            data[y][x][1] = (GLubyte)g;
            data[y][x][2] = (GLubyte)b;
        }
    }

    GLuint tex;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, S, S, 0, GL_RGB, GL_UNSIGNED_BYTE, data);

    return tex;
}

// Draws a textured cuboid centered at current origin.
void drawBox(float w, float h, float d, GLuint tex, float repeat)
{
    useTexture(tex);

    float x = w * 0.5f;
    float y = h * 0.5f;
    float z = d * 0.5f;

    float tx = w * repeat;
    float ty = h * repeat;
    float tz = d * repeat;

    glBegin(GL_QUADS);

    // Front face +Z
    glNormal3f(0, 0, 1);
    glTexCoord2f(0, 0);       glVertex3f(-x, -y,  z);
    glTexCoord2f(tx, 0);      glVertex3f( x, -y,  z);
    glTexCoord2f(tx, ty);     glVertex3f( x,  y,  z);
    glTexCoord2f(0, ty);      glVertex3f(-x,  y,  z);

    // Back face -Z
    glNormal3f(0, 0, -1);
    glTexCoord2f(0, 0);       glVertex3f( x, -y, -z);
    glTexCoord2f(tx, 0);      glVertex3f(-x, -y, -z);
    glTexCoord2f(tx, ty);     glVertex3f(-x,  y, -z);
    glTexCoord2f(0, ty);      glVertex3f( x,  y, -z);

    // Right face +X
    glNormal3f(1, 0, 0);
    glTexCoord2f(0, 0);       glVertex3f( x, -y,  z);
    glTexCoord2f(tz, 0);      glVertex3f( x, -y, -z);
    glTexCoord2f(tz, ty);     glVertex3f( x,  y, -z);
    glTexCoord2f(0, ty);      glVertex3f( x,  y,  z);

    // Left face -X
    glNormal3f(-1, 0, 0);
    glTexCoord2f(0, 0);       glVertex3f(-x, -y, -z);
    glTexCoord2f(tz, 0);      glVertex3f(-x, -y,  z);
    glTexCoord2f(tz, ty);     glVertex3f(-x,  y,  z);
    glTexCoord2f(0, ty);      glVertex3f(-x,  y, -z);

    // Top face +Y
    glNormal3f(0, 1, 0);
    glTexCoord2f(0, 0);       glVertex3f(-x,  y,  z);
    glTexCoord2f(tx, 0);      glVertex3f( x,  y,  z);
    glTexCoord2f(tx, tz);     glVertex3f( x,  y, -z);
    glTexCoord2f(0, tz);      glVertex3f(-x,  y, -z);

    // Bottom face -Y
    glNormal3f(0, -1, 0);
    glTexCoord2f(0, 0);       glVertex3f(-x, -y, -z);
    glTexCoord2f(tx, 0);      glVertex3f( x, -y, -z);
    glTexCoord2f(tx, tz);     glVertex3f( x, -y,  z);
    glTexCoord2f(0, tz);      glVertex3f(-x, -y,  z);

    glEnd();

    glDisable(GL_TEXTURE_2D);
}

void drawCylinderY(float radius, float height, GLuint tex)
{
    useTexture(tex);
    glPushMatrix();
        glTranslatef(0.0f, -height * 0.5f, 0.0f);
        glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
        gluCylinder(quadricObj, radius, radius, height, 32, 6);
        gluDisk(quadricObj, 0.0, radius, 32, 1);
        glTranslatef(0.0f, 0.0f, height);
        gluDisk(quadricObj, 0.0, radius, 32, 1);
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
}

void drawCylinderX(float radius, float height, GLuint tex)
{
    useTexture(tex);
    glPushMatrix();
        glTranslatef(-height * 0.5f, 0.0f, 0.0f);
        glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
        gluCylinder(quadricObj, radius, radius, height, 32, 6);
        gluDisk(quadricObj, 0.0, radius, 32, 1);
        glTranslatef(0.0f, 0.0f, height);
        gluDisk(quadricObj, 0.0, radius, 32, 1);
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
}

void drawCylinderZ(float radius, float height, GLuint tex)
{
    useTexture(tex);
    glPushMatrix();
        glTranslatef(0.0f, 0.0f, -height * 0.5f);
        gluCylinder(quadricObj, radius, radius, height, 32, 6);
        gluDisk(quadricObj, 0.0, radius, 32, 1);
        glTranslatef(0.0f, 0.0f, height);
        gluDisk(quadricObj, 0.0, radius, 32, 1);
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
}

void drawBitmapString3D(float x, float y, float z, const char *text)
{
    glDisable(GL_TEXTURE_2D);
    glDisable(GL_LIGHTING);
    glRasterPos3f(x, y, z);
    for (size_t i = 0; i < strlen(text); i++)
    {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, text[i]);
    }
    glEnable(GL_LIGHTING);
}

void drawBitmapString2D(float x, float y, const char *text)
{
    glRasterPos2f(x, y);
    for (size_t i = 0; i < strlen(text); i++)
    {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, text[i]);
    }
}

// ----------------------------- 2D planes for windows and picture frame -----------------------------
void drawQuadYZ(float x, float y1, float y2, float z1, float z2, float normalX)
{
    glNormal3f(normalX, 0.0f, 0.0f);
    glBegin(GL_QUADS);
        glVertex3f(x, y1, z1);
        glVertex3f(x, y1, z2);
        glVertex3f(x, y2, z2);
        glVertex3f(x, y2, z1);
    glEnd();
}

void drawTriangleYZ(float x, float y1, float z1, float y2, float z2, float y3, float z3, float normalX)
{
    glNormal3f(normalX, 0.0f, 0.0f);
    glBegin(GL_TRIANGLES);
        glVertex3f(x, y1, z1);
        glVertex3f(x, y2, z2);
        glVertex3f(x, y3, z3);
    glEnd();
}

void drawQuadXY(float z, float x1, float x2, float y1, float y2, float normalZ)
{
    glNormal3f(0.0f, 0.0f, normalZ);
    glBegin(GL_QUADS);
        glVertex3f(x1, y1, z);
        glVertex3f(x2, y1, z);
        glVertex3f(x2, y2, z);
        glVertex3f(x1, y2, z);
    glEnd();
}

void drawTriangleXY(float z, float x1, float y1, float x2, float y2, float x3, float y3, float normalZ)
{
    glNormal3f(0.0f, 0.0f, normalZ);
    glBegin(GL_TRIANGLES);
        glVertex3f(x1, y1, z);
        glVertex3f(x2, y2, z);
        glVertex3f(x3, y3, z);
    glEnd();
}

// ----------------------------- Animated outside view -----------------------------
void drawSideWindowScenery(int side, float zc)
{
    float x = side * 2.985f;
    float nx = -side;
    float yBottom = 1.18f;
    float yTop = 2.28f;
    float zLeft = zc - 1.02f;
    float zRight = zc + 1.02f;
    float width = zRight - zLeft;

    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);

    // Sky
    glColor3f(0.48f, 0.72f, 0.96f);
    drawQuadYZ(x, yBottom + 0.32f, yTop, zLeft, zRight, nx);

    // Distant mountains
    glColor3f(0.42f, 0.48f, 0.55f);
    drawTriangleYZ(x + side * 0.001f, 1.50f, zLeft, 2.12f, zLeft + 0.55f, 1.50f, zLeft + 1.05f, nx);
    drawTriangleYZ(x + side * 0.001f, 1.50f, zLeft + 0.75f, 2.05f, zLeft + 1.35f, 1.50f, zRight, nx);

    // Grass / land
    glColor3f(0.18f, 0.55f, 0.22f);
    drawQuadYZ(x, yBottom, yBottom + 0.33f, zLeft, zRight, nx);

    // Animated white fence lines
    glLineWidth(2.0f);
    glColor3f(0.92f, 0.92f, 0.86f);
    glBegin(GL_LINES);
    for (int i = 0; i < 7; i++)
    {
        float p = zLeft + fmodf(i * 0.50f + sceneryOffset * 0.85f, width);
        glVertex3f(x + side * 0.003f, 1.33f, p);
        glVertex3f(x + side * 0.003f, 1.42f, p + 0.20f);
    }
    glEnd();

    // Animated trees seen through the cabin window
    for (int i = 0; i < 6; i++)
    {
        float p = zLeft + fmodf(i * 0.58f + sceneryOffset * 1.25f, width);
        float trunkW = 0.025f;
        float treeH = 0.28f + (i % 3) * 0.04f;

        glColor3f(0.34f, 0.19f, 0.07f);
        drawQuadYZ(x + side * 0.004f, 1.18f, 1.40f, p - trunkW, p + trunkW, nx);

        glColor3f(0.05f, 0.38f, 0.12f);
        drawTriangleYZ(x + side * 0.006f, 1.33f, p - 0.16f, 1.33f, p + 0.16f, 1.33f + treeH, p, nx);
        drawTriangleYZ(x + side * 0.006f, 1.45f, p - 0.13f, 1.45f, p + 0.13f, 1.45f + treeH * 0.75f, p, nx);
    }

    glEnable(GL_LIGHTING);
}

void drawSideWindow(int side, float zc)
{
    float wallX = side * 3.02f;
    float frameX = side * 2.94f;

    drawSideWindowScenery(side, zc);

    // Semi-transparent glass layer
    glDisable(GL_LIGHTING);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glDepthMask(GL_FALSE);
    glColor4f(0.72f, 0.88f, 1.0f, 0.25f);
    drawQuadYZ(wallX, 1.18f, 2.28f, zc - 1.02f, zc + 1.02f, -side);
    glDepthMask(GL_TRUE);
    glDisable(GL_BLEND);
    glEnable(GL_LIGHTING);

    // Wooden frame surrounding the window
    glPushMatrix();
        glColor3f(1,1,1);
        glTranslatef(frameX, 2.33f, zc);
        drawBox(0.13f, 0.09f, 2.25f, texWood, 3.5f);
    glPopMatrix();

    glPushMatrix();
        glColor3f(1,1,1);
        glTranslatef(frameX, 1.13f, zc);
        drawBox(0.13f, 0.09f, 2.25f, texWood, 3.5f);
    glPopMatrix();

    glPushMatrix();
        glColor3f(1,1,1);
        glTranslatef(frameX, 1.73f, zc - 1.08f);
        drawBox(0.13f, 1.25f, 0.09f, texWood, 3.5f);
    glPopMatrix();

    glPushMatrix();
        glColor3f(1,1,1);
        glTranslatef(frameX, 1.73f, zc + 1.08f);
        drawBox(0.13f, 1.25f, 0.09f, texWood, 3.5f);
    glPopMatrix();

    // Middle vertical separator
    glPushMatrix();
        glTranslatef(frameX, 1.73f, zc);
        drawBox(0.11f, 1.15f, 0.06f, texMetal, 5.0f);
    glPopMatrix();
}

void drawFrontWindowScenery()
{
    float z = -9.99f;

    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);

    // Sky
    glColor3f(0.42f, 0.70f, 0.95f);
    drawQuadXY(z, -2.15f, 2.15f, 1.48f, 2.62f, 1.0f);

    // Mountains
    glColor3f(0.42f, 0.48f, 0.54f);
    drawTriangleXY(z - 0.002f, -2.15f, 1.48f, -1.10f, 2.22f, -0.05f, 1.48f, 1.0f);
    drawTriangleXY(z - 0.002f, -0.45f, 1.48f, 0.75f, 2.18f, 2.15f, 1.48f, 1.0f);

    // Grass and rail bed
    glColor3f(0.17f, 0.52f, 0.20f);
    drawQuadXY(z - 0.001f, -2.15f, 2.15f, 1.02f, 1.48f, 1.0f);

    glColor3f(0.25f, 0.22f, 0.19f);
    drawQuadXY(z - 0.003f, -0.90f, 0.90f, 1.02f, 1.48f, 1.0f);

    // Railway lines with perspective illusion
    glLineWidth(3.0f);
    glColor3f(0.70f, 0.70f, 0.68f);
    glBegin(GL_LINES);
        glVertex3f(-0.18f, 1.48f, z - 0.006f);
        glVertex3f(-0.78f, 1.02f, z - 0.006f);
        glVertex3f(0.18f, 1.48f, z - 0.006f);
        glVertex3f(0.78f, 1.02f, z - 0.006f);
    glEnd();

    // Animated sleepers moving toward viewer
    glLineWidth(2.0f);
    glColor3f(0.48f, 0.30f, 0.15f);
    glBegin(GL_LINES);
    for (int i = 0; i < 8; i++)
    {
        float t = fmodf(i * 0.13f + sceneryOffset * 0.09f, 0.78f);
        float y = 1.02f + t;
        if (y > 1.47f) continue;
        float half = 0.18f + (1.48f - y) * 1.20f;
        glVertex3f(-half, y, z - 0.008f);
        glVertex3f( half, y, z - 0.008f);
    }
    glEnd();

    glEnable(GL_LIGHTING);
}

void drawFrontWindow()
{
    drawFrontWindowScenery();

    // Glass
    glDisable(GL_LIGHTING);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glDepthMask(GL_FALSE);
    glColor4f(0.72f, 0.90f, 1.0f, 0.22f);
    drawQuadXY(-9.98f, -2.15f, 2.15f, 1.02f, 2.62f, 1.0f);
    glDepthMask(GL_TRUE);
    glDisable(GL_BLEND);
    glEnable(GL_LIGHTING);

    // Windshield frame
    glPushMatrix(); glTranslatef(0.0f, 2.67f, -9.90f); drawBox(4.55f, 0.10f, 0.12f, texWood, 3.0f); glPopMatrix();
    glPushMatrix(); glTranslatef(0.0f, 0.97f, -9.90f); drawBox(4.55f, 0.10f, 0.12f, texWood, 3.0f); glPopMatrix();
    glPushMatrix(); glTranslatef(-2.22f, 1.82f, -9.90f); drawBox(0.10f, 1.70f, 0.12f, texWood, 3.0f); glPopMatrix();
    glPushMatrix(); glTranslatef( 2.22f, 1.82f, -9.90f); drawBox(0.10f, 1.70f, 0.12f, texWood, 3.0f); glPopMatrix();
    glPushMatrix(); glTranslatef(0.0f, 1.82f, -9.895f); drawBox(0.08f, 1.63f, 0.11f, texMetal, 4.0f); glPopMatrix();
}

// ----------------------------- Train cabin objects -----------------------------
void drawCabinShell()
{
    // Floor
    glPushMatrix();
        glTranslatef(0.0f, -0.06f, -1.0f);
        drawBox(6.25f, 0.12f, 18.35f, texFloor, 1.2f);
    glPopMatrix();

    // Aisle carpet strip
    glPushMatrix();
        glTranslatef(0.0f, 0.015f, -1.0f);
        glScalef(1.0f, 1.0f, 1.0f);
        glColor3f(0.80f, 0.80f, 0.80f);
        drawBox(0.90f, 0.035f, 16.3f, texFabric, 1.0f);
    glPopMatrix();

    // Ceiling
    glPushMatrix();
        glTranslatef(0.0f, 3.04f, -1.0f);
        drawBox(6.25f, 0.10f, 18.35f, texWall, 1.0f);
    glPopMatrix();

    // Left and right walls
    glPushMatrix();
        glTranslatef(-3.08f, 1.50f, -1.0f);
        drawBox(0.12f, 3.0f, 18.35f, texWall, 1.0f);
    glPopMatrix();

    glPushMatrix();
        glTranslatef(3.08f, 1.50f, -1.0f);
        drawBox(0.12f, 3.0f, 18.35f, texWall, 1.0f);
    glPopMatrix();

    // Front driver wall
    glPushMatrix();
        glTranslatef(0.0f, 1.50f, -10.12f);
        drawBox(6.25f, 3.0f, 0.12f, texWall, 1.0f);
    glPopMatrix();

    // Rear wall
    glPushMatrix();
        glTranslatef(0.0f, 1.50f, 8.12f);
        drawBox(6.25f, 3.0f, 0.12f, texWall, 1.0f);
    glPopMatrix();

    // Ceiling long metal ribs
    for (int i = 0; i < 5; i++)
    {
        float x = -2.4f + i * 1.2f;
        glPushMatrix();
            glTranslatef(x, 2.94f, -1.0f);
            drawBox(0.06f, 0.06f, 17.2f, texMetal, 4.0f);
        glPopMatrix();
    }

    // Interior base trims along walls
    glPushMatrix(); glTranslatef(-2.96f, 0.15f, -1.0f); drawBox(0.15f, 0.20f, 17.6f, texWood, 2.0f); glPopMatrix();
    glPushMatrix(); glTranslatef( 2.96f, 0.15f, -1.0f); drawBox(0.15f, 0.20f, 17.6f, texWood, 2.0f); glPopMatrix();
}

void drawPassengerChair(int side, float z)
{
    // A single clear passenger chair. The back is near the wall and the cushion opens to the aisle.
    // The extra trims, gaps, head pillow, arm bars and metal legs make the chair readable from camera view.
    float wallX   = side * 2.72f;
    float seatX   = side * 2.18f;
    float aisleX  = side * 1.66f;

    // Dark shadow under cushion for better separation from the floor
    glColor3f(0.06f, 0.07f, 0.08f);
    glPushMatrix();
        glTranslatef(seatX, 0.335f, z);
        drawBox(0.92f, 0.06f, 0.60f, 0, 1.0f);
    glPopMatrix();

    // Main seat cushion
    glPushMatrix();
        glTranslatef(seatX, 0.52f, z);
        drawBox(0.92f, 0.24f, 0.60f, texFabric, 2.4f);
    glPopMatrix();

    // Slight front lip on the cushion, facing the aisle
    glPushMatrix();
        glTranslatef(aisleX, 0.58f, z);
        drawBox(0.13f, 0.18f, 0.58f, texFabric, 2.8f);
    glPopMatrix();

    // Tall backrest panel
    glPushMatrix();
        glTranslatef(wallX, 1.04f, z);
        drawBox(0.26f, 1.18f, 0.62f, texFabric, 2.2f);
    glPopMatrix();

    // Raised head pillow at the top of the backrest
    glPushMatrix();
        glTranslatef(side * 2.58f, 1.70f, z);
        drawBox(0.30f, 0.30f, 0.48f, texFabric, 3.0f);
    glPopMatrix();

    // Clear black side seams on the back cushion
    glColor3f(0.02f, 0.025f, 0.035f);
    glPushMatrix();
        glTranslatef(side * 2.43f, 1.05f, z - 0.325f);
        drawBox(0.055f, 1.00f, 0.035f, 0, 1.0f);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(side * 2.43f, 1.05f, z + 0.325f);
        drawBox(0.055f, 1.00f, 0.035f, 0, 1.0f);
    glPopMatrix();

    // Wooden armrest on aisle side
    glPushMatrix();
        glTranslatef(aisleX, 0.86f, z);
        drawBox(0.16f, 0.20f, 0.66f, texWood, 3.0f);
    glPopMatrix();

    // Wooden side rails make each individual chair look separate
    glPushMatrix();
        glTranslatef(seatX, 0.78f, z - 0.34f);
        drawBox(0.78f, 0.13f, 0.075f, texWood, 3.0f);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(seatX, 0.78f, z + 0.34f);
        drawBox(0.78f, 0.13f, 0.075f, texWood, 3.0f);
    glPopMatrix();

    // Metal front and rear legs
    float legXs[2] = { side * 1.84f, side * 2.48f };
    float legZs[2] = { z - 0.22f, z + 0.22f };
    for (int i = 0; i < 2; i++)
    {
        for (int j = 0; j < 2; j++)
        {
            glPushMatrix();
                glTranslatef(legXs[i], 0.245f, legZs[j]);
                drawBox(0.065f, 0.49f, 0.065f, texMetal, 5.0f);
            glPopMatrix();
        }
    }

    // Foot support bar below the cushion
    glPushMatrix();
        glTranslatef(side * 2.16f, 0.31f, z);
        drawCylinderZ(0.025f, 0.50f, texMetal);
    glPopMatrix();
}

void drawSeat(int side, float z)
{
    // One row block has two individual passenger chairs with a visible center gap.
    drawPassengerChair(side, z - 0.36f);
    drawPassengerChair(side, z + 0.36f);

    // Middle divider between the two chairs
    glPushMatrix();
        glTranslatef(side * 2.16f, 0.88f, z);
        drawBox(0.84f, 0.18f, 0.07f, texWood, 3.0f);
    glPopMatrix();

    // Common metal base frame for the double-seat unit
    glPushMatrix();
        glTranslatef(side * 2.16f, 0.17f, z);
        drawBox(1.02f, 0.07f, 1.35f, texMetal, 4.5f);
    glPopMatrix();
}

void drawSeats()
{
    // Rows are spaced slightly wider so every chair shape is easy to identify.
    float rows[] = {5.45f, 3.00f, 0.55f, -1.90f, -4.35f, -6.80f};
    int count = sizeof(rows) / sizeof(rows[0]);
    for (int i = 0; i < count; i++)
    {
        drawSeat(-1, rows[i]);
        drawSeat( 1, rows[i]);
    }
}

void drawFoldableTables()
{
    // A few compact wooden tables between seat groups
    float zs[] = {4.45f, 0.00f, -4.50f};
    for (int i = 0; i < 3; i++)
    {
        float z = zs[i];
        glPushMatrix();
            glTranslatef(0.0f, 0.78f, z);
            drawBox(1.05f, 0.09f, 0.70f, texWood, 3.0f);
        glPopMatrix();
        glPushMatrix();
            glTranslatef(0.0f, 0.39f, z);
            drawCylinderY(0.055f, 0.72f, texMetal);
        glPopMatrix();
        glPushMatrix();
            glTranslatef(0.0f, 0.06f, z);
            drawBox(0.55f, 0.06f, 0.42f, texMetal, 4.0f);
        glPopMatrix();

        // Cup on table
        glColor3f(0.95f, 0.95f, 0.90f);
        glPushMatrix();
            glTranslatef(0.25f, 0.88f, z + 0.12f);
            drawCylinderY(0.07f, 0.16f, 0);
        glPopMatrix();
    }
}

void drawLuggageRack(int side)
{
    // Wooden shelf and three metal rods above seats
    glPushMatrix();
        glTranslatef(side * 2.17f, 2.52f, -1.05f);
        drawBox(1.20f, 0.08f, 16.1f, texWood, 2.4f);
    glPopMatrix();

    for (int r = 0; r < 3; r++)
    {
        glPushMatrix();
            glTranslatef(side * (1.62f + r * 0.26f), 2.43f, -1.05f);
            drawCylinderZ(0.035f, 16.1f, texMetal);
        glPopMatrix();
    }

    // Support brackets
    for (int i = 0; i < 7; i++)
    {
        float z = 6.0f - i * 2.4f;
        glPushMatrix();
            glTranslatef(side * 2.70f, 2.22f, z);
            drawBox(0.07f, 0.50f, 0.07f, texMetal, 5.0f);
        glPopMatrix();
        glPushMatrix();
            glTranslatef(side * 2.28f, 2.30f, z);
            glRotatef(side * 25.0f, 0.0f, 0.0f, 1.0f);
            drawBox(0.52f, 0.06f, 0.07f, texMetal, 5.0f);
        glPopMatrix();
    }
}

void drawSmallBag(float x, float y, float z, float sx, float sy, float sz)
{
    glPushMatrix();
        glTranslatef(x, y, z);
        drawBox(sx, sy, sz, texLeather, 2.2f);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(x, y + sy * 0.58f, z);
        glColor3f(0.08f, 0.06f, 0.05f);
        drawCylinderX(0.025f, sx * 0.55f, 0);
    glPopMatrix();
}

void drawOverheadBags()
{
    drawSmallBag(-2.08f, 2.78f, 5.5f, 0.72f, 0.36f, 0.58f);
    drawSmallBag( 2.05f, 2.78f, 3.6f, 0.66f, 0.34f, 0.54f);
    drawSmallBag(-2.12f, 2.78f, -0.7f, 0.80f, 0.38f, 0.56f);
    drawSmallBag( 2.10f, 2.78f, -3.2f, 0.72f, 0.34f, 0.62f);
    drawSmallBag(-2.10f, 2.78f, -6.8f, 0.70f, 0.32f, 0.56f);
}

void drawCabinLights()
{
    glDisable(GL_LIGHTING);
    glColor3f(1.0f, 0.94f, 0.68f);
    for (int i = 0; i < 6; i++)
    {
        float z = 6.5f - i * 2.8f;
        glPushMatrix();
            glTranslatef(0.0f, 2.91f, z);
            drawBox(1.05f, 0.04f, 0.35f, 0, 1.0f);
        glPopMatrix();
    }
    glEnable(GL_LIGHTING);
}

void drawCeilingFan()
{
    // Ceiling rod
    glPushMatrix();
        glColor3f(1,1,1);
        glTranslatef(0.0f, 2.68f, -1.0f);
        drawCylinderY(0.04f, 0.55f, texMetal);
    glPopMatrix();

    // Motor hub
    glPushMatrix();
        glTranslatef(0.0f, 2.38f, -1.0f);
        drawCylinderY(0.16f, 0.16f, texMetal);
    glPopMatrix();

    // Rotating blades: object-coordinate rotation
    glPushMatrix();
        glTranslatef(0.0f, 2.32f, -1.0f);
        glRotatef(fanAngle, 0.0f, 1.0f, 0.0f);
        for (int i = 0; i < 4; i++)
        {
            glPushMatrix();
                glRotatef(i * 90.0f, 0.0f, 1.0f, 0.0f);
                glTranslatef(0.63f, 0.0f, 0.0f);
                drawBox(1.10f, 0.035f, 0.17f, texWood, 3.0f);
            glPopMatrix();
        }
    glPopMatrix();
}

void drawRoutePictureFrame()
{
    float z = 8.035f;

    // Frame on rear wall
    glPushMatrix(); glTranslatef(0.0f, 2.34f, z - 0.10f); drawBox(2.20f, 0.08f, 0.08f, texWood, 3.0f); glPopMatrix();
    glPushMatrix(); glTranslatef(0.0f, 1.30f, z - 0.10f); drawBox(2.20f, 0.08f, 0.08f, texWood, 3.0f); glPopMatrix();
    glPushMatrix(); glTranslatef(-1.10f, 1.82f, z - 0.10f); drawBox(0.08f, 1.08f, 0.08f, texWood, 3.0f); glPopMatrix();
    glPushMatrix(); glTranslatef( 1.10f, 1.82f, z - 0.10f); drawBox(0.08f, 1.08f, 0.08f, texWood, 3.0f); glPopMatrix();

    // Map/picture background
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);
    glColor3f(0.93f, 0.94f, 0.87f);
    drawQuadXY(z - 0.15f, -1.02f, 1.02f, 1.36f, 2.28f, -1.0f);

    // Route line
    glLineWidth(4.0f);
    glColor3f(0.02f, 0.22f, 0.72f);
    glBegin(GL_LINE_STRIP);
        glVertex3f(-0.86f, 1.55f, z - 0.18f);
        glVertex3f(-0.45f, 1.88f, z - 0.18f);
        glVertex3f( 0.10f, 1.70f, z - 0.18f);
        glVertex3f( 0.52f, 2.07f, z - 0.18f);
        glVertex3f( 0.86f, 1.86f, z - 0.18f);
    glEnd();

    // Stations
    float sx[] = {-0.86f, -0.45f, 0.10f, 0.52f, 0.86f};
    float sy[] = {1.55f, 1.88f, 1.70f, 2.07f, 1.86f};
    glColor3f(0.85f, 0.05f, 0.04f);
    for (int i = 0; i < 5; i++)
    {
        glBegin(GL_POLYGON);
        for (int a = 0; a < 20; a++)
        {
            float ang = a * 2.0f * PI / 20.0f;
            glVertex3f(sx[i] + cosf(ang) * 0.045f, sy[i] + sinf(ang) * 0.045f, z - 0.19f);
        }
        glEnd();
    }

    glColor3f(0.05f, 0.05f, 0.05f);
    drawBitmapString3D(-0.88f, 2.17f, z - 0.20f, "DHAKA EXPRESS ROUTE MAP");
    drawBitmapString3D(-0.87f, 1.40f, z - 0.20f, "animated windows + object/view transforms");
    glEnable(GL_LIGHTING);
}

void drawDriverConsole()
{
    // A small control desk under front window
    glPushMatrix();
        glTranslatef(0.0f, 0.72f, -8.90f);
        drawBox(2.65f, 0.50f, 0.55f, texMetal, 2.0f);
    glPopMatrix();

    glPushMatrix();
        glTranslatef(0.0f, 1.04f, -8.72f);
        glRotatef(-12.0f, 1.0f, 0.0f, 0.0f);
        drawBox(2.40f, 0.08f, 0.72f, texWood, 3.0f);
    glPopMatrix();

    // Screens/buttons
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);
    glColor3f(0.03f, 0.08f, 0.10f);
    drawQuadXY(-8.36f, -1.02f, -0.25f, 0.97f, 1.30f, 1.0f);
    drawQuadXY(-8.36f,  0.25f,  1.02f, 0.97f, 1.30f, 1.0f);
    glColor3f(0.05f, 0.85f, 0.32f);
    drawBitmapString3D(-0.95f, 1.15f, -8.34f, "SPEED 82 KM/H");
    glColor3f(0.30f, 0.70f, 1.0f);
    drawBitmapString3D(0.35f, 1.15f, -8.34f, "SIGNAL OK");
    glEnable(GL_LIGHTING);

    // Levers
    glPushMatrix();
        glTranslatef(-0.45f, 1.12f, -8.66f);
        glRotatef(-28.0f, 1.0f, 0.0f, 0.0f);
        drawCylinderY(0.035f, 0.42f, texMetal);
        glTranslatef(0.0f, 0.25f, 0.0f);
        glutSolidSphere(0.09f, 24, 12);
    glPopMatrix();

    glPushMatrix();
        glTranslatef(0.50f, 1.12f, -8.66f);
        glRotatef(-50.0f, 1.0f, 0.0f, 0.0f);
        drawCylinderY(0.035f, 0.36f, texMetal);
        glTranslatef(0.0f, 0.23f, 0.0f);
        glutSolidSphere(0.085f, 24, 12);
    glPopMatrix();
}

void drawTransformableSuitcase()
{
    // Object coordinate transformations controlled by keyboard.
    glPushMatrix();
        glTranslatef(objX, objY, objZ);       // translation in object coordinate workflow
        glRotatef(objRotY, 0.0f, 1.0f, 0.0f); // rotation
        glScalef(objScale, objScale, objScale); // scaling

        // body
        glPushMatrix();
            glTranslatef(0.0f, 0.38f, 0.0f);
            drawBox(0.62f, 0.78f, 0.36f, texLeather, 2.5f);
        glPopMatrix();

        // front pocket
        glPushMatrix();
            glTranslatef(0.0f, 0.36f, -0.185f);
            drawBox(0.45f, 0.42f, 0.035f, texWood, 3.0f);
        glPopMatrix();

        // telescopic handle
        glPushMatrix();
            glTranslatef(-0.18f, 0.94f, 0.0f);
            drawCylinderY(0.018f, 0.46f, texMetal);
        glPopMatrix();
        glPushMatrix();
            glTranslatef(0.18f, 0.94f, 0.0f);
            drawCylinderY(0.018f, 0.46f, texMetal);
        glPopMatrix();
        glPushMatrix();
            glTranslatef(0.0f, 1.18f, 0.0f);
            drawCylinderX(0.025f, 0.42f, texMetal);
        glPopMatrix();

        // wheels
        glColor3f(0.05f, 0.05f, 0.05f);
        for (int a = 0; a < 2; a++)
        {
            for (int b = 0; b < 2; b++)
            {
                glPushMatrix();
                    glTranslatef(a == 0 ? -0.23f : 0.23f, -0.04f, b == 0 ? -0.15f : 0.15f);
                    glutSolidSphere(0.07f, 18, 10);
                glPopMatrix();
            }
        }

        // local axes indicator to prove object-coordinate transformation
        glDisable(GL_LIGHTING);
        glLineWidth(2.0f);
        glBegin(GL_LINES);
            glColor3f(1,0,0); glVertex3f(0, 1.35f, 0); glVertex3f(0.45f, 1.35f, 0);
            glColor3f(0,1,0); glVertex3f(0, 1.35f, 0); glVertex3f(0, 1.75f, 0);
            glColor3f(0,0,1); glVertex3f(0, 1.35f, 0); glVertex3f(0, 1.35f, 0.45f);
        glEnd();
        glEnable(GL_LIGHTING);
    glPopMatrix();
}

void drawDoorDetails()
{
    // Rear door panels
    glPushMatrix();
        glTranslatef(-2.15f, 1.35f, 8.035f);
        drawBox(1.05f, 2.10f, 0.08f, texMetal, 1.6f);
    glPopMatrix();
    glPushMatrix();
        glTranslatef(2.15f, 1.35f, 8.035f);
        drawBox(1.05f, 2.10f, 0.08f, texMetal, 1.6f);
    glPopMatrix();

    // Door glass panels
    glDisable(GL_LIGHTING);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glDepthMask(GL_FALSE);
    glColor4f(0.75f, 0.90f, 1.0f, 0.35f);
    drawQuadXY(7.98f, -2.55f, -1.75f, 1.25f, 2.25f, -1.0f);
    drawQuadXY(7.98f,  1.75f,  2.55f, 1.25f, 2.25f, -1.0f);
    glDepthMask(GL_TRUE);
    glDisable(GL_BLEND);
    glEnable(GL_LIGHTING);

    // Door handles
    glPushMatrix(); glTranslatef(-1.65f, 1.20f, 7.88f); drawCylinderY(0.025f, 0.45f, texMetal); glPopMatrix();
    glPushMatrix(); glTranslatef( 1.65f, 1.20f, 7.88f); drawCylinderY(0.025f, 0.45f, texMetal); glPopMatrix();
}

void drawHandRails()
{
    // Long hand rails near ceiling
    glPushMatrix(); glTranslatef(-1.15f, 2.64f, -1.0f); drawCylinderZ(0.035f, 15.8f, texMetal); glPopMatrix();
    glPushMatrix(); glTranslatef( 1.15f, 2.64f, -1.0f); drawCylinderZ(0.035f, 15.8f, texMetal); glPopMatrix();

    // Hanging loops
    for (int s = -1; s <= 1; s += 2)
    {
        for (int i = 0; i < 8; i++)
        {
            float z = 6.2f - i * 1.9f;
            glPushMatrix();
                glTranslatef(s * 1.15f, 2.32f, z);
                drawCylinderY(0.015f, 0.36f, texMetal);
            glPopMatrix();
            glPushMatrix();
                glTranslatef(s * 1.15f, 2.10f, z);
                glScalef(1.0f, 0.65f, 1.0f);
                glColor3f(0.96f, 0.92f, 0.75f);
                glutSolidTorus(0.015f, 0.105f, 12, 24);
            glPopMatrix();
        }
    }
}

void drawWindows()
{
    float zPositions[] = {5.7f, 2.8f, -0.1f, -3.0f, -5.9f, -8.0f};
    int count = sizeof(zPositions) / sizeof(zPositions[0]);
    for (int i = 0; i < count; i++)
    {
        drawSideWindow(-1, zPositions[i]);
        drawSideWindow( 1, zPositions[i]);
    }
    drawFrontWindow();
}

void drawScene()
{
    drawCabinShell();
    drawWindows();
    drawSeats();
    drawFoldableTables();
    drawLuggageRack(-1);
    drawLuggageRack(1);
    drawOverheadBags();
    drawCabinLights();
    drawCeilingFan();
    drawRoutePictureFrame();
    drawDriverConsole();
    drawDoorDetails();
    drawHandRails();
    drawTransformableSuitcase();
}

// ----------------------------- Camera, lights and UI -----------------------------
void setupCamera()
{
    float yawR = degToRad(camYaw);
    float pitchR = degToRad(camPitch);

    float dirX = sinf(yawR) * cosf(pitchR);
    float dirY = sinf(pitchR);
    float dirZ = -cosf(yawR) * cosf(pitchR);

    gluLookAt(camX, camY, camZ,
              camX + dirX, camY + dirY, camZ + dirZ,
              0.0f, 1.0f, 0.0f);
}

void setupLighting()
{
    GLfloat ambient[]  = {0.30f, 0.30f, 0.32f, 1.0f};
    GLfloat diffuse[]  = {0.85f, 0.82f, 0.76f, 1.0f};
    GLfloat specular[] = {0.55f, 0.55f, 0.55f, 1.0f};
    GLfloat pos[]      = {0.0f, 2.80f, 2.5f, 1.0f};

    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
    glLightfv(GL_LIGHT0, GL_POSITION, pos);

    GLfloat ambient2[] = {0.05f, 0.07f, 0.10f, 1.0f};
    GLfloat diffuse2[] = {0.35f, 0.48f, 0.65f, 1.0f};
    GLfloat pos2[] = {0.0f, 1.8f, -9.2f, 1.0f};
    glLightfv(GL_LIGHT1, GL_AMBIENT, ambient2);
    glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuse2);
    glLightfv(GL_LIGHT1, GL_POSITION, pos2);
}

void drawHUD()
{
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0, winW, 0, winH);

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();

    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);
    glDisable(GL_DEPTH_TEST);

    // Transparent dark box
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColor4f(0.0f, 0.0f, 0.0f, 0.44f);
    glBegin(GL_QUADS);
        glVertex2f(12, winH - 130);
        glVertex2f(555, winH - 130);
        glVertex2f(555, winH - 12);
        glVertex2f(12, winH - 12);
    glEnd();
    glDisable(GL_BLEND);

    glColor3f(1.0f, 0.96f, 0.75f);
    drawBitmapString2D(24, winH - 34, "TRAIN CABIN SIMULATOR  |  OpenGL GLUT 3D Project");

    glColor3f(0.92f, 0.92f, 0.92f);
    drawBitmapString2D(24, winH - 57, "Viewing transform: W/S forward-back, A/D strafe, Q/E up-down, Arrow keys rotate camera");
    drawBitmapString2D(24, winH - 79, "Object transform suitcase: I/K move Z, J/L move X, U/O move Y, R/T rotate, Z/X scale");
    drawBitmapString2D(24, winH - 101, "C = reset camera/object, ESC = exit | Procedural textures: wall, wood, metal, fabric, floor");

    char info[180];
    sprintf(info, "Camera [%.1f, %.1f, %.1f]   Suitcase scale %.2f rot %.1f   Fan angle %.1f", camX, camY, camZ, objScale, objRotY, fanAngle);
    glColor3f(0.62f, 0.92f, 1.0f);
    drawBitmapString2D(24, winH - 123, info);

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);

    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();

    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    setupCamera();
    setupLighting();

    drawScene();

    // Left-corner writing/HUD removed as requested.
    glutSwapBuffers();
}

void reshape(int w, int h)
{
    if (h == 0) h = 1;
    winW = w;
    winH = h;
    glViewport(0, 0, w, h);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(62.0, (double)w / (double)h, 0.05, 80.0);

    glMatrixMode(GL_MODELVIEW);
}

void update(int value)
{
    fanAngle += 6.0f;
    if (fanAngle > 360.0f) fanAngle -= 360.0f;

    sceneryOffset += 0.035f;
    if (sceneryOffset > 20.0f) sceneryOffset -= 20.0f;

    glutPostRedisplay();
    glutTimerFunc(16, update, 0);
}

void resetAll()
{
    camX = 0.0f;
    camY = 1.55f;
    camZ = 6.6f;
    camYaw = 0.0f;
    camPitch = -2.0f;

    objX = 0.0f;
    objY = 0.32f;
    objZ = 1.65f;
    objRotY = 0.0f;
    objScale = 1.0f;
}

void keyboard(unsigned char key, int x, int y)
{
    float speed = 0.18f;
    float yawR = degToRad(camYaw);

    float forwardX = sinf(yawR);
    float forwardZ = -cosf(yawR);
    float rightX = cosf(yawR);
    float rightZ = sinf(yawR);

    switch (key)
    {
        // Viewing-coordinate transformation controls
        case 'w': case 'W': camX += forwardX * speed; camZ += forwardZ * speed; break;
        case 's': case 'S': camX -= forwardX * speed; camZ -= forwardZ * speed; break;
        case 'a': case 'A': camX -= rightX * speed; camZ -= rightZ * speed; break;
        case 'd': case 'D': camX += rightX * speed; camZ += rightZ * speed; break;
        case 'q': case 'Q': camY -= speed; if (camY < 0.35f) camY = 0.35f; break;
        case 'e': case 'E': camY += speed; if (camY > 2.75f) camY = 2.75f; break;

        // Object-coordinate transformation controls for suitcase
        case 'i': case 'I': objZ -= 0.12f; break;
        case 'k': case 'K': objZ += 0.12f; break;
        case 'j': case 'J': objX -= 0.12f; break;
        case 'l': case 'L': objX += 0.12f; break;
        case 'u': case 'U': objY += 0.08f; break;
        case 'o': case 'O': objY -= 0.08f; if (objY < 0.20f) objY = 0.20f; break;
        case 'r': case 'R': objRotY -= 8.0f; break;
        case 't': case 'T': objRotY += 8.0f; break;
        case 'z': case 'Z': objScale -= 0.05f; if (objScale < 0.45f) objScale = 0.45f; break;
        case 'x': case 'X': objScale += 0.05f; if (objScale > 1.80f) objScale = 1.80f; break;

        case 'c': case 'C': resetAll(); break;
        case 27: exit(0); break;
        default: break;
    }
    glutPostRedisplay();
}

void specialKeys(int key, int x, int y)
{
    switch (key)
    {
        case GLUT_KEY_LEFT:  camYaw -= 3.0f; break;
        case GLUT_KEY_RIGHT: camYaw += 3.0f; break;
        case GLUT_KEY_UP:    camPitch += 2.0f; if (camPitch > 35.0f) camPitch = 35.0f; break;
        case GLUT_KEY_DOWN:  camPitch -= 2.0f; if (camPitch < -35.0f) camPitch = -35.0f; break;
        default: break;
    }
    glutPostRedisplay();
}

void initOpenGL()
{
    glClearColor(0.04f, 0.05f, 0.07f, 1.0f);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_LIGHT1);
    glEnable(GL_COLOR_MATERIAL);
    glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
    glEnable(GL_NORMALIZE);
    glShadeModel(GL_SMOOTH);

    GLfloat matSpec[] = {0.38f, 0.38f, 0.38f, 1.0f};
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, matSpec);
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 32.0f);

    quadricObj = gluNewQuadric();
    gluQuadricNormals(quadricObj, GLU_SMOOTH);
    gluQuadricTexture(quadricObj, GL_TRUE);

    texWood = createProceduralTexture(0);
    texFabric = createProceduralTexture(1);
    texFloor = createProceduralTexture(2);
    texWall = createProceduralTexture(3);
    texMetal = createProceduralTexture(4);
    texLeather = createProceduralTexture(5);
}

int main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
    glutInitWindowSize(winW, winH);
    glutInitWindowPosition(80, 40);
    glutCreateWindow("Premium Train Cabin Simulator - OpenGL GLUT Project");

    initOpenGL();

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(specialKeys);
    glutTimerFunc(16, update, 0);

    glutMainLoop();
    return 0;
}
