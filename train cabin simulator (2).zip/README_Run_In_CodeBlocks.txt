TRAIN CABIN SIMULATOR - OpenGL GLUT C++ Project
================================================

Project concept
---------------
This project creates a premium 3D train cabin simulator using OpenGL GLUT.
It includes a realistic interior train cabin with newly improved clear individual passenger chairs, windows, moving outside scenery, ceiling fan, luggage rack, driver console, route picture frame, textured walls/floor/furniture, and interactive object/view transformations.

Latest update
-------------
- Chairs/seats were redesigned to look clearer and more realistic.
- Each row now has individual passenger chairs with separate cushions, tall backrests, head pillows, aisle armrests, wooden dividers, seams, metal legs and a base frame.
- The left-corner on-screen writing/HUD was removed from the display.

Main requirements covered
-------------------------
1. One group may contain 3 members at most.
2. A 3D scene is generated: complete train cabin interior.
3. Basic transformations are included: translation, rotation and scaling.
4. Complex objects are included: individual chairs, luggage rack, suitcase, fan, windows, console, doors, route map.
5. Continuous rotating object: ceiling fan rotates continuously.
6. Window/external view: animated scenery is visible through side windows and front windshield.
7. Object coordinate transformation: suitcase can be moved, rotated and scaled.
8. Viewing coordinate transformation: camera can move and rotate.
9. Textures on surfaces: procedural textures for wood, fabric, floor, wall, metal and suitcase.

How to run in Code::Blocks
--------------------------
Option A: Open the included Code::Blocks project file:
1. Open TrainCabinSimulator.cbp in Code::Blocks.
2. Make sure FreeGLUT / GLUT is installed and configured.
3. Build and run.

Option B: Create a fresh GLUT project:
1. File > New > Project > GLUT Project.
2. Replace generated main.cpp with this main.cpp.
3. Link these libraries in Project > Build options > Linker settings:
   - freeglut
   - opengl32
   - glu32
   If your setup uses old GLUT, use glut32 instead of freeglut.
4. Build and run.

Controls
--------
Viewing coordinate / camera:
W/S       Move forward/backward
A/D       Strafe left/right
Q/E       Move down/up
Arrow keys Rotate the camera view

Object coordinate / suitcase:
I/K       Move suitcase along Z
J/L       Move suitcase along X
U/O       Move suitcase up/down
R/T       Rotate suitcase
Z/X       Scale down/up

Other:
C         Reset camera and object
ESC       Exit

No external image files are required.
All textures are generated procedurally inside the C++ code.
